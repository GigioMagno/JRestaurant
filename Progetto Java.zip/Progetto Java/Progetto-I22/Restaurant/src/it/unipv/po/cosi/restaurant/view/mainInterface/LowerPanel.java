package it.unipv.po.cosi.restaurant.view.mainInterface;

import javax.swing.*;

import it.unipv.po.cosi.restaurant.view.subMenu.Status;
import it.unipv.po.cosi.restaurant.view.subMenu.smlisteners.TableSubMenu;
import java.awt.event.*;
import java.awt.*;

public class LowerPanel extends JPanel {

	
public LowerPanel() {
	setBackground(Color.black);
	
	
	
	
}
		
	
	
}
