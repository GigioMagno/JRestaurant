package it.unipv.po.cosi.restaurant.model.orderModel;

public enum Status {

	FREE,PRENOTED,ORDERED,ORDERED_DESSERT,READY_TO_PAY;
	
}
