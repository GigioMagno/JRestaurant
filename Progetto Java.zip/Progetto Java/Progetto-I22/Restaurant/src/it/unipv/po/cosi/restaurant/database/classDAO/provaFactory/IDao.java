package it.unipv.po.cosi.restaurant.database.classDAO.provaFactory;

import java.util.ArrayList;

public interface IDao {

	public final static String schema = "restaurant";
	public void initialize();
	
}
